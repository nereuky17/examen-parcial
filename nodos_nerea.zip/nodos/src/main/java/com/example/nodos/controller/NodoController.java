
package com.example.nodos.controller;

import com.example.nodos.service.NodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/nodos")
public class NodoController {

    @Autowired
    private NodoService nodoService;

    @GetMapping("/{numero}/{nombre}")
    public String procesarNodo(@PathVariable int numero, @PathVariable String nombre) {
        return nodoService.procesarNodo(numero, nombre);
    }
}
    