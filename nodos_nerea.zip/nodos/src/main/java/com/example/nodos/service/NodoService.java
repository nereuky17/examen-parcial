
package com.example.nodos.service;

import org.springframework.stereotype.Service;

@Service
public class NodoService {

    public String procesarNodo(int numero, String nombre) {
        if (numero % 2 == 0) {
            return String.valueOf(numero + nombre.length());
        } else {
            return nombre;
        }
    }
}
    