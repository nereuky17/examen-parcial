
package com.example.nodos.controller;

import com.example.nodos.service.NodoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NodoController.class)
public class NodoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NodoService nodoService;

    @Test
    public void testProcesarNodoImpar() throws Exception {
        int numero = 3;
        String nombre = "Juan";
        when(nodoService.procesarNodo(numero, nombre)).thenReturn(nombre);

        mockMvc.perform(get("/nodos/{numero}/{nombre}", numero, nombre))
                .andExpect(status().isOk())
                .andExpect(content().string(nombre));
    }

    @Test
    public void testProcesarNodoPar() throws Exception {
        int numero = 4;
        String nombre = "Ana";
        String resultado = String.valueOf(numero + nombre.length());
        when(nodoService.procesarNodo(numero, nombre)).thenReturn(resultado);

        mockMvc.perform(get("/nodos/{numero}/{nombre}", numero, nombre))
                .andExpect(status().isOk())
                .andExpect(content().string(resultado));
    }
}
    